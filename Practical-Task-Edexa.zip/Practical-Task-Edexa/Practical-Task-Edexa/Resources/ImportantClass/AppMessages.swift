//
//  AppMessages.swift
//  Practical-Task-Edexa
//
//  Created by Devang Lakhani  on 7/17/21.
//  Copyright © 2021 Devang Lakhani. All rights reserved.
//

import Foundation

// MARK: Web Operation
let _appName        = "Practical-Edexa"
let kInternetDown  = "No Internet Connection"
let kConnecting    = "connecting..."
let kHostDown      = "your host seems to be down"
let kTimeOut       = "the request timed out"
let kInternalError      = "internal error"
let kTokenExpire        = "token expire please login again"
let kUnauthenticated    = "Unauthenticated"
